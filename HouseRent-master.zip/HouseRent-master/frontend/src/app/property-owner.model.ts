export interface PropertyOwner {
  id: string;
  name: string;
  email: string;
  password: string;
  contactRequestedBy: string | null;

}
