export interface Tenant {
  id: number;
  name: string;
  email: string;
  password: string;
}
